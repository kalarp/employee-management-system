Employee Management System v1.0.0
================================

Installation:
1. Extract all files to a folder of your choice
2. Run EmployeeManagement.exe

First Run:
- The system will create a database file automatically
- Default admin credentials: admin/admin (change immediately)

Folders:
- templates/ - Document templates
- documents/ - Generated documents
- exports/ - Exported data

Support:
Email: support@yourcompany.com
